export const ADD_ITEMS = 'ADD_ITEMS';
export const SHOW_INSTOCK = 'SHOW_INSTOCK';
export const SEARCH_PRODUCT = 'SEARCH_PRODUCT';